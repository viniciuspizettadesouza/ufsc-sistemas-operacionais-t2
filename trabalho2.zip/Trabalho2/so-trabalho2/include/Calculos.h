#include <stdbool.h>
#include <stdio.h>

unsigned contadorDeBits(unsigned int numero);
bool multiploPorDois(unsigned int numero);
unsigned int kbInBytes(int kb);
unsigned int BytesInKB(int bytes);